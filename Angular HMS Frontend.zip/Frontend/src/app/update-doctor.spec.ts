import { UpdateDoctor } from './update-doctor';

describe('UpdateDoctor', () => {
  it('should create an instance', () => {
    expect(new UpdateDoctor()).toBeTruthy();
  });
});

export class Appointment {
    ap_id!: number;
    d_name!: string;
    p_name!: string;

    address!: string;
    ap_date!: string; 
    ap_time!: string;
    gender!: string;
    disease!: string
   

}
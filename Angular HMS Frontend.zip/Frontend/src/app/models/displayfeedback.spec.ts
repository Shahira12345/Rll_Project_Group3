import { Displayfeedback } from './displayfeedback';

describe('Displayfeedback', () => {
  it('should create an instance', () => {
    expect(new Displayfeedback()).toBeTruthy();
  });
});

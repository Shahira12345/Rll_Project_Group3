export class DoctorLogin {
    username!: string;
    password!: string
    constructor() {} 
}